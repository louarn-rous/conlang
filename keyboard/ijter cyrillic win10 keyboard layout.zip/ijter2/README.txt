
launch 'setup.exe' with administrator privileges to install the Ijter Cyrillic keyboard layout.
it will display as Serbian (Cyrillic, Serbia). this may cause conflicts if actual Serbian Cyrillic is installed, which
is why I have included the original .klc file which can be modified (potentially resolving this issue).
be aware that the layout's language being set to Serbian Cyrillic is done so that it may work with the proper cyrillic characters,
however inputing Ӧӧ, Һһ or Ӱӱ may cause issues with non-unicode programs. this may be the case with additional characters
if the layout is modified to corresond to a different language (especially one that does not use the cyrillic alphabet).

this was tested and worked as intended on windows 10, although i cannot guarantee this will be the same with older versions
of windows. if you are looking for a way to input ijter cyrillic on linux, see the github for 'ijter-cyrillic.mim' (to
be used with ibus and m17n).

made by louarn-rous on the 27th of April 2023
https://github.com/louarn-rous/conlang/